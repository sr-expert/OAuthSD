# oidcclient
Un client OIDC pour SPIP. Permet à une application SPIP de proposer l’authentification avec OpenID Connect, à côté de l’authentification classique.

Les développeurs d’application SPIP pourront renforcer la protection de l’accès aux fonctionnalités réservées et à l’espace privé en limitant l’accès aux seules personnes enregistrées sur le serveur OIDC configuré.
Installation et documentation : https://oa.dnc.global/web/61
