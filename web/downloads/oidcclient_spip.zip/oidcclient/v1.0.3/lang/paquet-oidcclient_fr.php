<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/oidcclient/trunk/lang/
if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// O
	'oidcclient_description' => 'Un utilisateur qui souhaite utiliser OIDC pour s\'identifier doit être enregistré sur un serveur OIDC que lui a désigné le concepteur de l\'application.',
	'oidcclient_slogan' => 'Authentification des auteurs et visiteurs à l’aide d\'OpenID Connect'
);
