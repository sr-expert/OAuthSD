<?php
/* [dnc9'] cryptos.php  2018/03/26
Utilise les fonctions de la bibliothèque PHP OpenSSL pour le cryptage et le décryptage symétrique.
Voir : http://php.net/manual/fr/book.openssl.php
[33az]

Les trois fonctions qui suivent sont cryptées avec la clé dynamique $x...

OauthSD project
This code is not an open source!
You can not access, dispose, modify, transmit etc. this code without the written permission of DnC.
You can only use one coded copy provided you have a particular license from DnC.
Auteur : Bertrand Degoy 
Copyright (c) 2016-2019 DnC  
All rights reserved
*/

$x12507183 = 2741 * 4563;   // ionCube dynamic key 

// @ioncube.dk $x12507183 -> "12507183" RANDOM
function define_keys() {
    define('KEY', "85861b51b063f867fb0e43b3dc85831d24181e465efd05f3e8d25818d8125fe8"); 
    define('HKEY',"35cffafe002333fca221f57a85c4b43c490f708107ed7bff56f01e06d0272b66");
}
define_keys();

/**
* Cryptage avec Open SSL
* 
* @var string $plaintext message à crypter
* @param string $key : la clé (sans laquelle ciphertext ne pourra être décrypté).
* @return mixed  : URL Safe B64 encoded encrypted text.
*/
// @ioncube.dk $x12507183 -> "12507183" RANDOM
function encrypt( $plaintext, $key = null ) {
    if ( is_null( $key ) ) $key = KEY;
    $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");  // ou AES-256-CBC ? 
    $iv = openssl_random_pseudo_bytes($ivlen);
    $ciphertext_raw = openssl_encrypt($plaintext, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
    $hmac = hash_hmac('sha256', $ciphertext_raw, HKEY, $as_binary=true);   
    $ciphertext = urlSafeB64Encode( $iv.$hmac.$ciphertext_raw );
    return $ciphertext;
}

/**
* Décryptage avec Open SSL
* 
* @param string $ciphertext : chaîne à décrypter.
* @param string $key : la clé avec laquelle la chaîne a été cryptée. 
* @return mixed
*/
// @ioncube.dk $x12507183 -> "12507183" RANDOM
function decrypt( $ciphertext, $key = KEY ) {
    if ( is_null( $key ) ) $key = KEY;
    $c = urlSafeB64Decode($ciphertext);
    $ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
    $iv = substr($c, 0, $ivlen);
    $hmac = substr($c, $ivlen, $sha2len=32);
    $ciphertext_raw = substr($c, $ivlen+$sha2len);
    $original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
    $calcmac = hash_hmac('sha256', $ciphertext_raw, HKEY, $as_binary=true);    
    if (@hash_equals($hmac, $calcmac)) { //PHP 5.6+ timing attack safe comparison
        return $original_plaintext;
    } else {
        return '';
    }
}

/**
* Retourne un hash pour $raw, avec un éventuel salt.
* 
* @param mixed $raw
* @param mixed $salt
* @param mixed $key défaut : HKEY
*/
function hmac( $raw, $salt = "", $key = HKEY ) {
    return base64_encode( hash_hmac('sha256', $raw . $salt, $key, $as_binary=true) );
}


/**
* Cette fonction peut être exécutée manuellement pour générer les clés KEY et HKEY.
* 
* @param mixed $byteLength. 16 à 64 ? défaut : 32 . En réalité donne le double !
*/

function getRandomBytes ( $byteLength = 32 ) {
    if (function_exists('openssl_random_pseudo_bytes')) {
        $randomBytes = openssl_random_pseudo_bytes($byteLength, $cryptoStrong);
        if ($cryptoStrong)
            return bin2hex($randomBytes);
    } else return False; 
}

// fin crypto.php
